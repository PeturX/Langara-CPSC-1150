public class Hello
{
	public static void main(String[] args)
	{
		System.out.println(" ._____.");
		System.out.println("/ \\_____\\");
		System.out.println("| | 0 0 |");
		System.out.println("|_|__H__|");
	}	
}
